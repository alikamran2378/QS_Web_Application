// Wait until the page has loaded before running any code
document.addEventListener('DOMContentLoaded', function () {

  const navbar = document.getElementById('mainNav');
  const backToTop = document.getElementById('backToTop');

  /* ===== 1. Image fallback =====
     If a local image (images/hero.jpg etc.) is missing,
     use the placeholder URL stored in data-fallback. */
  document.querySelectorAll('img[data-fallback]').forEach(function (img) {
    img.addEventListener('error', function () {
      if (img.src !== img.dataset.fallback) {
        img.src = img.dataset.fallback;
      }
    }, { once: true });
  });

  /* ===== 2. Navbar style + back-to-top button on scroll ===== */
  function handleScroll() {
    navbar.classList.toggle('scrolled', window.scrollY > 50);
    backToTop.classList.toggle('show', window.scrollY > 500);
  }
  window.addEventListener('scroll', handleScroll);
  handleScroll(); // run once on load

  backToTop.addEventListener('click', function () {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  /* ===== 3. Smooth scrolling + close mobile menu =====
     Only for links that point to a real section (not plain "#"). */
  const menu = document.getElementById('navMenu');
  document.querySelectorAll('a[href^="#"]').forEach(function (link) {
    link.addEventListener('click', function (e) {
      const id = link.getAttribute('href');
      if (id.length > 1 && document.querySelector(id)) {
        e.preventDefault();
        document.querySelector(id).scrollIntoView({ behavior: 'smooth' });
        // close the hamburger menu after choosing a link
        if (menu.classList.contains('show')) {
          bootstrap.Collapse.getOrCreateInstance(menu).hide();
        }
      } else if (id === '#') {
        e.preventDefault(); // placeholder link: stay on the page
      }
    });
  });

  /* ===== 4. Active nav link based on current section ===== */
  const sectionIds = ['home', 'about', 'services', 'gallery', 'contact'];
  const navLinks = document.querySelectorAll('#navMenu .nav-link');
  function setActiveLink() {
    let current = 'home';
    sectionIds.forEach(function (id) {
      const section = document.getElementById(id);
      if (section && window.scrollY >= section.offsetTop - 140) current = id;
    });
    navLinks.forEach(function (link) {
      link.classList.toggle('active', link.getAttribute('href') === '#' + current);
    });
  }
  window.addEventListener('scroll', setActiveLink);
  setActiveLink();

  /* ===== 5. Scroll reveal (IntersectionObserver) ===== */
  const revealObserver = new IntersectionObserver(function (entries, observer) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target); // animate only once
      }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.reveal').forEach(function (el) { revealObserver.observe(el); });

  /* ===== 6. Animated number counters ===== */
  function runCounter(el) {
    const target = Number(el.dataset.target);
    const duration = 1800; // milliseconds
    const start = performance.now();
    function tick(now) {
      const progress = Math.min((now - start) / duration, 1);
      el.textContent = Math.floor(progress * target);
      if (progress < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }
  const statsObserver = new IntersectionObserver(function (entries, observer) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.querySelectorAll('.counter').forEach(runCounter);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.4 });
  statsObserver.observe(document.getElementById('stats'));

  /* ===== 7. Gallery modal ===== */
  const modalEl = document.getElementById('galleryModal');
  const modalImage = document.getElementById('modalImage');
  const galleryModal = new bootstrap.Modal(modalEl);
  document.querySelectorAll('.gallery-item').forEach(function (item) {
    item.addEventListener('click', function (e) {
      e.preventDefault();
      const thumb = item.querySelector('img');
      // use the large image if it exists, otherwise reuse the thumbnail
      modalImage.src = thumb.currentSrc.includes('picsum') ? item.dataset.full : thumb.src;
      modalImage.alt = thumb.alt;
      galleryModal.show();
    });
  });

});
