
/* QS Printers Admin - Login Behaviour */

(function () {
    const form = document.getElementById('loginForm');
    const email = document.getElementById('email');
    const pwd = document.getElementById('password');

    const toggle = document.getElementById('togglePassword');
    const icon = document.getElementById('togglePasswordIcon');

    const alertBox = document.getElementById('formAlert');
    const btn = document.getElementById('loginBtn');
    const spinner = document.getElementById('loginSpinner');

    // Display current year
    document.getElementById('year').textContent =
        new Date().getFullYear();

    // Show / Hide Password
    toggle.addEventListener('click', function () {
        const show = pwd.type === 'password';

        pwd.type = show ? 'text' : 'password';

        icon.className = show
            ? 'bi bi-eye-slash'
            : 'bi bi-eye';

        toggle.setAttribute('aria-pressed', String(show));

        toggle.setAttribute(
            'aria-label',
            show ? 'Hide password' : 'Show password'
        );
    });

    // Display error message
    function showError(message) {
        alertBox.textContent = message;
        alertBox.classList.remove('d-none');
    }

    // Login Form Submission
    form.addEventListener('submit', function (event) {
        event.preventDefault();

        // Hide previous error
        alertBox.classList.add('d-none');

        // Enable Bootstrap validation
        form.classList.add('was-validated');

        // Check required fields and email format
        if (!form.checkValidity()) {
            return;
        }

        // Demo credentials for frontend testing only
        const correctEmail = 'admin@qsprinters.com';
        const correctPassword = 'Admin123';

        if (
            email.value.trim() === correctEmail &&
            pwd.value === correctPassword
        ) {
            // Show loading indicator
            btn.disabled = true;
            spinner.classList.remove('d-none');

            // Open dashboard
            window.location.href = 'dashboard.html';
        } else {
            showError('Invalid email or password. Please try again.');
        }
    });

})();