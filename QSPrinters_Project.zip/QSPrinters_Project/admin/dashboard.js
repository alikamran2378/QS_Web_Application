/* Dashboard rendering from sample data. Later: fetch from Laravel endpoints. */
(function () {
  const d = window.QS_SAMPLE;
  const pkr = function (n) { return 'PKR ' + Number(n).toLocaleString('en-PK'); };

  const cards = [
    { label: 'Total Orders',        value: d.stats.totalOrders.toLocaleString(),   icon: 'bi-cart-check',       tone: 'primary' },
    { label: 'Pending Orders',      value: d.stats.pendingOrders.toLocaleString(), icon: 'bi-hourglass-split',  tone: 'warning' },
    { label: 'Total Products',      value: d.stats.totalProducts.toLocaleString(), icon: 'bi-box-seam',         tone: 'info' },
    { label: 'Total Customers',     value: d.stats.totalCustomers.toLocaleString(),icon: 'bi-people',           tone: 'success' },
    { label: 'Revenue',             value: pkr(d.stats.revenue),                   icon: 'bi-cash-stack',       tone: 'success' },
    { label: 'Outstanding Payments',value: pkr(d.stats.outstanding),               icon: 'bi-exclamation-circle',tone: 'danger' }
  ];

  document.getElementById('statCards').innerHTML = cards.map(function (c) {
    return '<div class="col-12 col-sm-6 col-xl-4">' +
      '<div class="card stat-card h-100"><div class="card-body d-flex align-items-center gap-3">' +
        '<span class="stat-icon bg-' + c.tone + '-subtle text-' + c.tone + '-emphasis"><i class="bi ' + c.icon + '"></i></span>' +
        '<div><div class="text-body-secondary small">' + c.label + '</div>' +
        '<div class="fs-4 fw-bold">' + c.value + '</div></div>' +
      '</div></div></div>';
  }).join('');

  const orderTone = {
    'Pending': 'warning', 'In Production': 'primary', 'Ready': 'info',
    'Shipped': 'secondary', 'Delivered': 'success', 'Cancelled': 'danger'
  };
  const payTone = {
    'Pending': 'warning', 'Partial': 'info', 'Completed': 'success',
    'Failed': 'danger', 'Refunded': 'secondary'
  };
  function badge(text, tone) {
    return '<span class="badge text-bg-' + tone + '">' + text + '</span>';
  }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (ch) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch];
    });
  }

  document.getElementById('recentOrdersBody').innerHTML = d.recentOrders.map(function (o) {
    return '<tr>' +
      '<td class="fw-semibold">' + esc(o.id) + '</td>' +
      '<td>' + esc(o.customer) + '</td>' +
      '<td>' + esc(o.date) + '</td>' +
      '<td>' + pkr(o.total) + '</td>' +
      '<td>' + badge(esc(o.status), orderTone[o.status] || 'secondary') + '</td>' +
      '<td>' + badge(esc(o.payment), payTone[o.payment] || 'secondary') + '</td>' +
      '<td class="text-end"><a href="orders.html?id=' + encodeURIComponent(o.id) + '" class="btn btn-sm btn-outline-secondary">View</a></td>' +
    '</tr>';
  }).join('');
})();
