/* Shared admin layout: renders the sidebar into desktop + mobile containers.
   Later this becomes a Blade layout (resources/views/admin/layouts/app.blade.php). */
(function () {
  const current = location.pathname.split('/').pop() || 'dashboard.html';

  function sidebarHtml() {
    const links = window.QS_NAV.map(function (n) {
      const active = n.href === current ? ' active' : '';
      return '<li class="nav-item"><a class="nav-link' + active + '" href="' + n.href + '">' +
             '<i class="bi ' + n.icon + '"></i><span>' + n.label + '</span></a></li>';
    }).join('');

    return '' +
      '<div class="d-flex align-items-center gap-2 px-3 py-3 border-bottom border-light border-opacity-10">' +
        '<span class="brand-mark bg-white text-dark">QS</span>' +
        '<span class="fw-semibold fs-5">QS Printers</span>' +
      '</div>' +
      '<ul class="nav flex-column gap-1 p-3">' + links + '</ul>' +
      '<div class="px-3 pb-3 mt-auto">' +
        // Laravel: make this a POST form with @csrf to route('admin.logout')
        '<a class="nav-link logout" href="login.html"><i class="bi bi-box-arrow-left"></i><span>Logout</span></a>' +
      '</div>';
  }

  document.querySelectorAll('[data-sidebar]').forEach(function (el) {
    el.innerHTML = sidebarHtml();
  });
})();
