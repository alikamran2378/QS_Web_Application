
(function () {
    const orders = window.QS_SAMPLE.recentOrders;

    const customers = [
        {
            name: "Ali Khan",
            phone: "923001234567"
        },
        {
            name: "Ahmed Traders",
            phone: "923121234567"
        },
        {
            name: "Sara Malik",
            phone: "923331234567"
        },
        {
            name: "City Store",
            phone: "923451234567"
        },
        {
            name: "Print House",
            phone: "923001112233"
        }
    ];

    // Calculate how many orders belong to each customer
    customers.forEach(function (customer) {
        customer.totalOrders = orders.filter(function (order) {
            return order.customer === customer.name;
        }).length;
    });

    const searchInput = document.getElementById("customerSearch");
    const tableBody = document.getElementById("customersTableBody");

    document.getElementById("customerCount").textContent =
        customers.length;

    function escapeHTML(value) {
        return String(value).replace(/[&<>"']/g, function (char) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            }[char];
        });
    }

    function displayCustomers() {
        const search = searchInput.value.trim().toLowerCase();

        const filteredCustomers = customers.filter(function (customer) {
            return customer.name.toLowerCase().includes(search) ||
                   customer.phone.includes(search);
        });

        if (filteredCustomers.length === 0) {
            tableBody.innerHTML =
                '<tr><td colspan="4" class="text-center py-4">' +
                'No customers found.</td></tr>';
        } else {
            tableBody.innerHTML = filteredCustomers.map(function (customer) {
                const message = encodeURIComponent(
                    "Hello " + customer.name +
                    ", thank you for contacting QS Printers!"
                );

                const whatsappLink =
                    "https://wa.me/" + customer.phone +
                    "?text=" + message;

                return `
                    <tr>
                        <td class="fw-semibold">
                            ${escapeHTML(customer.name)}
                        </td>

                        <td>${escapeHTML(customer.phone)}</td>

                        <td>${customer.totalOrders}</td>

                        <td class="text-end">
                            <a
                                href="${whatsappLink}"
                                target="_blank"
                                rel="noopener noreferrer"
                                class="btn btn-sm btn-success">
                                <i class="bi bi-whatsapp me-1"></i>
                                WhatsApp
                            </a>
                        </td>
                    </tr>
                `;
            }).join("");
        }

        document.getElementById("customerResult").textContent =
            "Showing " + filteredCustomers.length +
            " of " + customers.length + " customers";
    }

    searchInput.addEventListener("input", displayCustomers);

    displayCustomers();
})();