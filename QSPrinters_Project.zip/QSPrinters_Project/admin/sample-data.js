
window.QS_SAMPLE = {
    stats: {
        totalOrders: 5,
        pendingOrders: 2,
        totalProducts: 12,
        totalCustomers: 4,
        revenue: 85000,
        outstanding: 15000
    },

    recentOrders: [
        {
            id: "QS-1001",
            customer: "Ali Khan",
            date: "2026-10-08",
            total: 25000,
            status: "Pending",
            payment: "Pending"
        },
        {
            id: "QS-1002",
            customer: "Ahmed Traders",
            date: "2026-10-07",
            total: 40000,
            status: "In Production",
            payment: "Partial"
        },
        {
            id: "QS-1003",
            customer: "Sara Malik",
            date: "2026-10-06",
            total: 12000,
            status: "Ready",
            payment: "Completed"
        },
        {
            id: "QS-1004",
            customer: "City Store",
            date: "2026-10-05",
            total: 18000,
            status: "Delivered",
            payment: "Completed"
        },
        {
            id: "QS-1005",
            customer: "Print House",
            date: "2026-10-04",
            total: 5000,
            status: "Cancelled",
            payment: "Refunded"
        }
    ]
};
window.QS_NAV = [
    {
        label: "Dashboard",
        href: "dashboard.html",
        icon: "bi-speedometer2"
    },
    {
        label: "Orders",
        href: "orders.html",
        icon: "bi-cart-check"
    },
    {
        label: "Customers",
        href: "customer.html",
        icon: "bi-people"
    }
];