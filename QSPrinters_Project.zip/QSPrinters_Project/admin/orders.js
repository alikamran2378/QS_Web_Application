
(function () {
    const data = window.QS_SAMPLE;

    if (!data || !Array.isArray(data.recentOrders)) {
        document.getElementById("ordersTableBody").innerHTML =
            '<tr><td colspan="7" class="text-center text-danger">Order data could not be loaded. Check sample-data.js.</td></tr>';
        return;
    }

    const orders = data.recentOrders;

    const searchInput = document.getElementById("searchOrder");
    const statusFilter = document.getElementById("statusFilter");
    const paymentFilter = document.getElementById("paymentFilter");
    const tableBody = document.getElementById("ordersTableBody");

    const orderTone = {
        "Pending": "warning",
        "In Production": "primary",
        "Ready": "info",
        "Shipped": "secondary",
        "Delivered": "success",
        "Cancelled": "danger"
    };

    const paymentTone = {
        "Pending": "warning",
        "Partial": "info",
        "Completed": "success",
        "Failed": "danger",
        "Refunded": "secondary"
    };

    function escapeHTML(value) {
        return String(value).replace(/[&<>"']/g, function (char) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            }[char];
        });
    }

    function money(amount) {
        return "PKR " + Number(amount).toLocaleString("en-PK");
    }

    function makeBadge(value, tones) {
        const safeValue = escapeHTML(value);

        return '<span class="badge text-bg-' +
            (tones[value] || "secondary") + '">' +
            safeValue + '</span>';
    }

    // Update summary cards
    document.getElementById("totalOrders").textContent = orders.length;

    document.getElementById("pendingOrders").textContent =
        orders.filter(function (order) {
            return order.status === "Pending";
        }).length;

    document.getElementById("productionOrders").textContent =
        orders.filter(function (order) {
            return order.status === "In Production";
        }).length;

    document.getElementById("deliveredOrders").textContent =
        orders.filter(function (order) {
            return order.status === "Delivered";
        }).length;

    // Display orders
    function displayOrders() {
        const search = searchInput.value.trim().toLowerCase();
        const status = statusFilter.value;
        const payment = paymentFilter.value;

        const filteredOrders = orders.filter(function (order) {
            const matchesSearch =
                String(order.id).toLowerCase().includes(search) ||
                String(order.customer).toLowerCase().includes(search);

            const matchesStatus =
                status === "" || order.status === status;

            const matchesPayment =
                payment === "" || order.payment === payment;

            return matchesSearch && matchesStatus && matchesPayment;
        });

        if (filteredOrders.length === 0) {
            tableBody.innerHTML =
                '<tr><td colspan="7" class="text-center py-4">' +
                'No matching orders found.</td></tr>';
        } else {
            tableBody.innerHTML = filteredOrders.map(function (order) {
                return `
                    <tr>
                        <td class="fw-semibold">${escapeHTML(order.id)}</td>
                        <td>${escapeHTML(order.customer)}</td>
                        <td>${escapeHTML(order.date)}</td>
                        <td>${money(order.total)}</td>
                        <td>${makeBadge(order.status, orderTone)}</td>
                        <td>${makeBadge(order.payment, paymentTone)}</td>
                        <td class="text-end">
                            <button
                                type="button"
                                class="btn btn-sm btn-outline-primary view-order"
                                data-order-id="${escapeHTML(order.id)}">
                                <i class="bi bi-eye me-1"></i>View
                            </button>
                        </td>
                    </tr>
                `;
            }).join("");
        }

        document.getElementById("resultCount").textContent =
            "Showing " + filteredOrders.length +
            " of " + orders.length + " orders";
    }

    // Search and filters
    searchInput.addEventListener("input", displayOrders);
    statusFilter.addEventListener("change", displayOrders);
    paymentFilter.addEventListener("change", displayOrders);

    // Open order details
    tableBody.addEventListener("click", function (event) {
        const button = event.target.closest(".view-order");

        if (!button) return;

        const order = orders.find(function (item) {
            return String(item.id) === button.dataset.orderId;
        });

        if (!order) return;

        document.getElementById("orderModalTitle").textContent =
            "Order " + order.id;

        document.getElementById("orderDetails").innerHTML = `
            <p><strong>Order ID:</strong> ${escapeHTML(order.id)}</p>
            <p><strong>Customer:</strong> ${escapeHTML(order.customer)}</p>
            <p><strong>Order Date:</strong> ${escapeHTML(order.date)}</p>
            <p><strong>Total Amount:</strong> ${money(order.total)}</p>
            <p><strong>Order Status:</strong>
                ${makeBadge(order.status, orderTone)}</p>
            <p class="mb-0"><strong>Payment Status:</strong>
                ${makeBadge(order.payment, paymentTone)}</p>
        `;

        bootstrap.Modal.getOrCreateInstance(
            document.getElementById("orderModal")
        ).show();
    });

    // Initial display
    displayOrders();
})();