/* =========================================================
   QS Printers - Products Page Script
   All product information lives in the `products` array.
   Later, this array can be replaced by data from Laravel.
   ========================================================= */

// ---------- 1. PRODUCT DATA ----------
const products = [
  {
    id: 1,
    name: "Custom Printed Boxes",
    category: "Boxes",
    image: "images/box.jpg",
    description: "Sturdy boxes printed with your logo and design, ideal for retail and gifting.",
    sizes: "Small, Medium, Large, Custom sizes",
    material: "Kraft board, Duplex board, Corrugated board",
    printing: "Full colour offset, Logo printing, Matte/Gloss lamination",
    moq: "100 pieces",
    info: "Free design guidance available. Production time depends on quantity."
  },
  {
    id: 2,
    name: "Cake Bases",
    category: "Cake Bases",
    image: "images/cake-base.jpg",
    description: "Strong, food-safe cake bases in popular shapes and sizes for bakeries.",
    sizes: "6 inch, 8 inch, 10 inch, 12 inch",
    material: "Food-grade board with foil or paper finish",
    printing: "Plain, Foil finish, Printed pattern",
    moq: "200 pieces",
    info: "Suitable for round, square and heart-shaped cakes."
  },
  {
    id: 3,
    name: "Printed Paper Bags",
    category: "Bags",
    image: "images/bags.jpg",
    description: "Eco-friendly paper bags with sharp, vibrant printing for your brand.",
    sizes: "Small, Medium, Large, Extra Large",
    material: "Kraft paper, Art paper",
    printing: "One colour, Full colour, Logo stamping",
    moq: "250 pieces",
    info: "Available with twisted paper or flat handles."
  },
  {
    id: 4,
    name: "Custom Packaging Boxes",
    category: "Packaging",
    image: "images/packaging.jpg",
    description: "Packaging boxes made to fit your product perfectly and protect it in transit.",
    sizes: "Made to your exact measurements",
    material: "Corrugated board, Rigid board, Duplex board",
    printing: "Full colour, Spot UV, Embossing",
    moq: "100 pieces",
    info: "Ideal for e-commerce, food, cosmetics and electronics."
  },
  {
    id: 5,
    name: "Luxury Gift Boxes",
    category: "Boxes",
    image: "images/gift-box.jpg",
    description: "Elegant rigid gift boxes with premium finishes for special occasions.",
    sizes: "Small, Medium, Large, Custom sizes",
    material: "Rigid board with art paper wrap",
    printing: "Hot foil stamping, Embossing, Soft-touch lamination",
    moq: "50 pieces",
    info: "Magnetic closure and ribbon options available."
  },
  {
    id: 6,
    name: "Custom Cake Boards",
    category: "Cake Bases",
    image: "images/cake-board.jpg",
    description: "Thick cake boards cut to your size, available with branded printing.",
    sizes: "8 inch to 16 inch, Custom shapes",
    material: "Thick MDF-style board, Corrugated board",
    printing: "Plain, Foil wrapped, Logo printed",
    moq: "100 pieces",
    info: "Great for tiered and heavy cakes."
  },
  {
    id: 7,
    name: "Branded Shopping Bags",
    category: "Bags",
    image: "images/shopping-bag.jpg",
    description: "Premium shopping bags that carry your brand wherever customers go.",
    sizes: "Small, Medium, Large",
    material: "Art card, Kraft paper, Laminated paper",
    printing: "Full colour, Foil logo, Matte/Gloss lamination",
    moq: "200 pieces",
    info: "Rope, ribbon or die-cut handle options."
  },
  {
    id: 8,
    name: "Custom Printed Packaging",
    category: "Custom Printing",
    image: "images/custom-packaging.jpg",
    description: "Fully customised printed packaging created from your own artwork.",
    sizes: "Custom sizes",
    material: "Paper, Board, Corrugated, Specialty stock",
    printing: "Offset, Digital, Foil, Spot UV",
    moq: "100 pieces",
    info: "Send us your design or let our team help you create one."
  }
];

// ---------- 2. STATE (current filter values) ----------
let activeCategory = "All";
let searchText = "";
let sortMode = "featured";

// ---------- 3. ELEMENT REFERENCES ----------
const grid = document.getElementById("productGrid");
const noProducts = document.getElementById("noProducts");
const resultCount = document.getElementById("resultCount");
const searchInput = document.getElementById("searchInput");
const sortSelect = document.getElementById("sortSelect");
const categoryButtons = document.querySelectorAll("#categoryFilters button");
const clearBtn = document.getElementById("clearFilters");
const navbar = document.getElementById("mainNavbar");
const backToTop = document.getElementById("backToTop");

// Simple grey placeholder used if an image file is missing
const fallbackImage =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    "<svg xmlns='http://www.w3.org/2000/svg' width='600' height='420'>" +
    "<rect width='100%' height='100%' fill='#e9eef4'/>" +
    "<text x='50%' y='50%' fill='#7a8a9a' font-size='26' font-family='Arial' " +
    "text-anchor='middle' dominant-baseline='middle'>QS Printers</text></svg>"
  );

// ---------- 4. BUILD ONE PRODUCT CARD ----------
function createCard(product, index) {
  const col = document.createElement("div");
  col.className = "col-lg-3 col-md-6 col-12"; // 4 / 2 / 1 per row
  col.innerHTML = `
    <div class="card product-card" style="animation-delay:${index * 0.06}s">
      <div class="product-img-wrap">
        <img src="${product.image}" alt="${product.name}" loading="lazy">
      </div>
      <div class="card-body d-flex flex-column">
        <span class="badge badge-category align-self-start">${product.category}</span>
        <h5 class="card-title">${product.name}</h5>
        <p class="card-text">${product.description}</p>
        <div class="mt-auto d-grid gap-2">
          <button class="btn btn-outline-qs view-details" data-id="${product.id}">View Details</button>
          <a href="custom-order.html" class="btn btn-qs">Order Now</a>
        </div>
      </div>
    </div>`;

  // If image fails to load, show the placeholder
  col.querySelector("img").addEventListener("error", function () {
    this.src = fallbackImage;
  });
  return col;
}

// ---------- 5. FILTER + SEARCH + SORT, THEN SHOW ----------
function renderProducts() {
  const term = searchText.trim().toLowerCase();

  // a) filter by category AND search text
  let list = products.filter(function (p) {
    const matchCategory = activeCategory === "All" || p.category === activeCategory;
    const matchSearch =
      p.name.toLowerCase().includes(term) ||
      p.category.toLowerCase().includes(term) ||
      p.description.toLowerCase().includes(term);
    return matchCategory && matchSearch;
  });

  // b) sort (copy first so the original order stays "Featured")
  list = list.slice();
  if (sortMode === "az") list.sort((a, b) => a.name.localeCompare(b.name));
  if (sortMode === "za") list.sort((a, b) => b.name.localeCompare(a.name));

  // c) draw cards
  grid.innerHTML = "";
  list.forEach((p, i) => grid.appendChild(createCard(p, i)));

  // d) count + empty message
  resultCount.textContent = "Showing " + list.length + (list.length === 1 ? " product" : " products");
  noProducts.classList.toggle("d-none", list.length !== 0);
}

// ---------- 6. EVENTS ----------
// Category buttons
categoryButtons.forEach(function (btn) {
  btn.addEventListener("click", function () {
    categoryButtons.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    activeCategory = btn.dataset.category;
    renderProducts();
  });
});

// Search (runs on every keystroke)
searchInput.addEventListener("input", function () {
  searchText = searchInput.value;
  renderProducts();
});

// Sorting
sortSelect.addEventListener("change", function () {
  sortMode = sortSelect.value;
  renderProducts();
});

// Clear filters
clearBtn.addEventListener("click", function () {
  searchText = "";
  activeCategory = "All";
  sortMode = "featured";
  searchInput.value = "";
  sortSelect.value = "featured";
  categoryButtons.forEach(b => b.classList.toggle("active", b.dataset.category === "All"));
  renderProducts();
});

// ---------- 7. DETAILS MODAL ----------
const productModal = new bootstrap.Modal(document.getElementById("productModal"));

// One listener on the grid handles every "View Details" button (event delegation)
grid.addEventListener("click", function (e) {
  const btn = e.target.closest(".view-details");
  if (!btn) return;

  const product = products.find(p => p.id === Number(btn.dataset.id));
  if (!product) return;

  document.getElementById("modalTitle").textContent = product.name;
  document.getElementById("modalCategory").textContent = product.category;
  document.getElementById("modalDescription").textContent = product.description;
  document.getElementById("modalSizes").textContent = product.sizes;
  document.getElementById("modalMaterial").textContent = product.material;
  document.getElementById("modalPrinting").textContent = product.printing;
  document.getElementById("modalMoq").textContent = product.moq;
  document.getElementById("modalInfo").textContent = product.info;

  const img = document.getElementById("modalImage");
  img.onerror = function () { img.src = fallbackImage; };
  img.src = product.image;
  img.alt = product.name;

  productModal.show();
});

// ---------- 8. NAVBAR SCROLL EFFECT + BACK TO TOP ----------
function handleScroll() {
  navbar.classList.toggle("scrolled", window.scrollY > 50);
  backToTop.classList.toggle("show", window.scrollY > 300);
}
window.addEventListener("scroll", handleScroll);
handleScroll();

backToTop.addEventListener("click", function () {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

// ---------- 9. START ----------
renderProducts();
