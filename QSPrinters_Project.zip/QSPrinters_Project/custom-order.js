// QS Printers - Custom Order page (frontend only, no backend)
document.addEventListener('DOMContentLoaded', () => {
  const $ = (id) => document.getElementById(id);
  const form = $('customOrderForm');
  const requiredIds = ['fullName', 'email', 'phone', 'category', 'productName', 'quantity', 'reqDate'];

  // Required date cannot be in the past
  $('reqDate').min = new Date().toISOString().split('T')[0];

  // ---------- Validation ----------
  function checkField(el) {
    let ok = el.value.trim() !== '';
    if (ok && el.id === 'email') ok = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(el.value.trim());
    if (ok && el.id === 'phone') ok = /^[0-9+\-\s()]{7,15}$/.test(el.value.trim());
    if (ok && el.id === 'quantity') ok = Number.isInteger(+el.value) && +el.value >= 1;
    if (ok && el.id === 'reqDate') ok = el.value >= el.min;
    el.classList.toggle('is-invalid', !ok);
    el.classList.toggle('is-valid', ok);
    return ok;
  }
  requiredIds.forEach((id) => {
    const el = $(id);
    el.addEventListener('blur', () => checkField(el));
    el.addEventListener('input', () => el.classList.contains('is-invalid') && checkField(el));
  });

  // ---------- Selectable option cards ----------
  function syncOptions() {
    form.querySelectorAll('.opt').forEach((label) => {
      label.classList.toggle('active', label.querySelector('input').checked);
    });
  }

  // ---------- Character counter ----------
  const notes = $('notes');
  notes.addEventListener('input', () => { $('charCount').textContent = `${notes.value.length} / 500 characters`; });

  // ---------- Design choice + file upload ----------
  const dropZone = $('dropZone'), fileInput = $('designFile');
  const allowed = ['pdf', 'jpg', 'jpeg', 'png', 'ai', 'psd'];

  function showFile(file) {
    const ext = file.name.split('.').pop().toLowerCase();
    $('fileError').classList.toggle('d-none', allowed.includes(ext));
    if (!allowed.includes(ext)) { clearFile(); $('fileError').classList.remove('d-none'); return; }
    $('fileName').textContent = file.name;
    $('fileSize').textContent = (file.size / 1024 / 1024).toFixed(2) + ' MB';
    const img = $('filePreview'), isImg = ['jpg', 'jpeg', 'png'].includes(ext);
    img.classList.toggle('d-none', !isImg);
    $('fileIcon').classList.toggle('d-none', isImg);
    if (isImg) img.src = URL.createObjectURL(file);
    $('fileInfo').classList.remove('d-none');
  }
  function clearFile() { fileInput.value = ''; $('fileInfo').classList.add('d-none'); }

  dropZone.addEventListener('click', () => fileInput.click());
  dropZone.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); } });
  fileInput.addEventListener('change', () => fileInput.files[0] && showFile(fileInput.files[0]));
  $('removeFile').addEventListener('click', clearFile);
  ['dragenter', 'dragover'].forEach((ev) => dropZone.addEventListener(ev, (e) => { e.preventDefault(); dropZone.classList.add('dragover'); }));
  ['dragleave', 'drop'].forEach((ev) => dropZone.addEventListener(ev, (e) => { e.preventDefault(); dropZone.classList.remove('dragover'); }));
  dropZone.addEventListener('drop', (e) => {
    if (e.dataTransfer.files[0]) { fileInput.files = e.dataTransfer.files; showFile(e.dataTransfer.files[0]); }
  });
  form.querySelectorAll('input[name="has_design"]').forEach((r) => r.addEventListener('change', () => {
    $('uploadWrap').classList.toggle('d-none', r.value === 'no' && r.checked);
  }));

  // ---------- Delivery method ----------
  function syncDelivery() {
    const delivery = form.delivery_method.value === 'Delivery';
    $('deliveryBox').classList.toggle('d-none', !delivery);
  }

  // ---------- Order summary ----------
  function checked(name) { return [...form.querySelectorAll(`input[name="${name}"]:checked`)].map((i) => i.value); }
  function updateSummary() {
    const v = (id) => $(id).value.trim();
    const dims = [v('length'), v('width'), v('height')];
    const size = dims.some(Boolean) ? dims.map((d) => d || '?').join(' x ') + ' ' + v('unit') : '';
    const material = [v('material'), v('thickness') !== 'Standard' ? v('thickness') : ''].filter(Boolean).join(', ');
    const printing = [form.printing.value, form.printing.value !== 'No Printing' ? form.sides.value : ''].filter(Boolean).join(' - ');
    const set = (id, text) => { $(id).textContent = text || '-'; };
    set('sCategory', v('category')); set('sName', v('productName')); set('sQty', v('quantity'));
    set('sSize', size); set('sMaterial', material); set('sPrinting', printing);
    set('sFinishing', checked('finishing[]').join(', ')); set('sDelivery', form.delivery_method.value);
    const touched = [v('category'), v('productName'), v('quantity'), size, v('material'), checked('finishing[]').length ? 'x' : '', form.printing.value !== 'No Printing' ? 'x' : ''].some(Boolean);
    $('summaryEmpty').classList.toggle('d-none', touched);
    $('summaryList').classList.toggle('d-none', !touched);
  }

  form.addEventListener('input', updateSummary);
  form.addEventListener('change', () => { syncOptions(); syncDelivery(); updateSummary(); });
  syncOptions(); syncDelivery(); updateSummary();

  // ---------- Submit (demo only: nothing is sent anywhere) ----------
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const results = requiredIds.map((id) => checkField($(id)));
    if (results.includes(false)) {
      const firstBad = requiredIds.map($).find((el) => el.classList.contains('is-invalid'));
      firstBad.scrollIntoView({ behavior: 'smooth', block: 'center' });
      firstBad.focus({ preventScroll: true });
      return;
    }
    // Later (Laravel phase): build FormData(form) here and send it to the backend.
    new bootstrap.Modal($('successModal')).show();
  });

  // ---------- Reset ----------
  function resetAll() {
    form.reset(); clearFile();
    form.querySelectorAll('.is-valid, .is-invalid').forEach((el) => el.classList.remove('is-valid', 'is-invalid'));
    $('uploadWrap').classList.remove('d-none'); $('fileError').classList.add('d-none');
    $('charCount').textContent = '0 / 500 characters';
    syncOptions(); syncDelivery(); updateSummary();
  }
  $('resetBtn').addEventListener('click', resetAll);
  $('successModal').addEventListener('hidden.bs.modal', resetAll);

  // ---------- Reveal animation ----------
  const io = new IntersectionObserver((entries) => entries.forEach((en) => {
    if (en.isIntersecting) { en.target.classList.add('show'); io.unobserve(en.target); }
  }), { threshold: .15 });
  document.querySelectorAll('.reveal').forEach((el) => io.observe(el));
});
